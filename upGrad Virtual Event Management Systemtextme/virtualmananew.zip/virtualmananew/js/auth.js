// Authentication logic

function login(){

let email=document.getElementById("email").value;
let pass=document.getElementById("password").value;

if(email==="admin@upgrad.com" && pass==="12345"){

sessionStorage.setItem("login",true);
window.location="events.html";

}else{
alert("Invalid credentials");
}

}

function checkLogin(){

if(!sessionStorage.getItem("login")){
alert("Unauthorized access");
window.location="login.html";
}

}

function logout(){

sessionStorage.clear();
window.location="login.html";

}