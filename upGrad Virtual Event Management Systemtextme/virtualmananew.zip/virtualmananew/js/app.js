/* =========================
   HOME EVENTS
========================= */

function loadHomeEvents(){

if(!db){
setTimeout(loadHomeEvents,200);
return;
}

let tx = db.transaction("events","readonly");
let store = tx.objectStore("events");

let req = store.getAll();

req.onsuccess = function(){
displayHomeEvents(req.result);
};

}

function displayHomeEvents(events){

let container = document.getElementById("homeEvents");

if(!container) return;

container.innerHTML = "";

if(events.length === 0){
container.innerHTML = "<p>No events available</p>";
return;
}

let currentUser = localStorage.getItem("currentUser");

events.forEach(e => {

let registrations = JSON.parse(localStorage.getItem("registrations")) || [];

let isRegistered = registrations.some(r => 
r.id === e.id && r.email === currentUser
);

container.innerHTML += `

<div class="col-md-4">
<div class="card p-3 m-2">

<h5>${e.name}</h5>

<p><b>ID:</b> ${e.id}</p>
<p><b>Category:</b> ${e.category}</p>
<p><b>Date:</b> ${e.date}</p>

${
isRegistered 
? `<button class="btn btn-success w-100" onclick="joinEvent('${e.id}','${e.url}')">Join Event</button>`
: `<button class="btn btn-primary w-100" onclick="registerEvent('${e.id}','${e.name}','${e.url}')">Register</button>`
}

</div>
</div>

`;

});

}

/* =========================
   REGISTER EVENT
========================= */

function registerEvent(id,name,url){

localStorage.setItem("selectedEvent", JSON.stringify({
id:id,
name:name,
url:url
}));

window.location = "user_register.html";

}

/* =========================
   JOIN EVENT (FINAL FIX)
========================= */

function joinEvent(id,url){

let currentUser = localStorage.getItem("currentUser");

if(!currentUser){
alert("Please register first!");
window.location = "user_register.html";
return;
}

let registrations = JSON.parse(localStorage.getItem("registrations")) || [];

let isRegistered = registrations.some(r => 
r.id === id && r.email === currentUser
);

if(isRegistered){

alert("You joined the event successfully!");

window.open(url, "_blank");

}else{

alert("Please register for this event first!");
window.location = "user_register.html";

}

}

/* =========================
   SAVE REGISTRATION (FINAL)
========================= */

function saveRegistration(){

let firstName = document.getElementById("firstName").value;
let lastName = document.getElementById("lastName").value;
let email = document.getElementById("email").value;

let event = JSON.parse(localStorage.getItem("selectedEvent"));

if(!firstName || !lastName || !email){
alert("Please fill all fields!");
return;
}

/* save user */
localStorage.setItem("currentUser", email.toLowerCase());

let registrations = JSON.parse(localStorage.getItem("registrations")) || [];

let exists = registrations.some(e => 
e.id === event.id && e.email === email.toLowerCase()
);

if(exists){
alert("Already registered!");
window.location = "index.html";
return;
}

/* save */
registrations.push({
id: event.id,
eventName: event.name,
email: email.toLowerCase()
});

localStorage.setItem("registrations", JSON.stringify(registrations));

alert("Registration successful!");

window.location = "index.html";

}

/* =========================
   ADMIN ADD EVENT
========================= */

function addEvent(){

let event = {
id: document.getElementById("id").value,
name: document.getElementById("name").value,
category: document.getElementById("category").value,
date: document.getElementById("date").value,
time: document.getElementById("time").value,
url: document.getElementById("url").value
};

if(!event.id || !event.name || !event.date || !event.url){
alert("Fill required fields");
return;
}

let tx = db.transaction("events","readwrite");
let store = tx.objectStore("events");

let req = store.add(event);

req.onsuccess = function(){

alert("Event Added!");
loadEvents();
localStorage.setItem("eventsUpdated", Date.now());

};

}

/* =========================
   LOAD EVENTS (ADMIN)
========================= */

function loadEvents(){

if(!db){
setTimeout(loadEvents,200);
return;
}

let tx = db.transaction("events","readonly");
let store = tx.objectStore("events");

let req = store.getAll();

req.onsuccess = function(){
displayEvents(req.result);
};

}

function displayEvents(data){

let container = document.getElementById("events");

container.innerHTML = "";

data.forEach(e => {

container.innerHTML += `

<div class="col-md-4">
<div class="card p-3 m-2">

<h5>${e.name}</h5>

<p>${e.id}</p>
<p>${e.category}</p>
<p>${e.date}</p>

<a href="${e.url}" target="_blank">Preview</a>

<button onclick="deleteEvent('${e.id}')" class="btn btn-danger mt-2">
Delete
</button>

</div>
</div>

`;

});

}

/* =========================
   DELETE EVENT
========================= */

function deleteEvent(id){

let tx = db.transaction("events","readwrite");
let store = tx.objectStore("events");

let req = store.delete(id);

req.onsuccess = function(){

alert("Deleted!");
loadEvents();
localStorage.setItem("eventsUpdated", Date.now());

};

}

/* =========================
   LOGOUT
========================= */

function logout(){

localStorage.removeItem("isLoggedIn");
localStorage.removeItem("currentUser");

alert("Logged out!");

window.location = "login.html";

}