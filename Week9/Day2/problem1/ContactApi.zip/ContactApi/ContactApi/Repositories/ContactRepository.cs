﻿using ContactApi.Models;

namespace ContactApi.Repositories
{
    public class ContactRepository : IContactRepository
    {
        private readonly List<Contact> _contacts = new()
        {
            new Contact { Id = 1, Name = "Madee", Email = "madee@gmail.com" },
            new Contact { Id = 2, Name = "Shine", Email = "shine@gmail.com" }
        };

        public List<Contact> GetAll()
        {
            Console.WriteLine("Fetching from DB...");
            return _contacts;
        }

        public Contact GetById(int id)
        {
            Console.WriteLine("Fetching from DB...");
            return _contacts.FirstOrDefault(x => x.Id == id);
        }
    }
}