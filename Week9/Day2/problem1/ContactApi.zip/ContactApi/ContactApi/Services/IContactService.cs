﻿using ContactApi.Models;

namespace ContactApi.Services
{
    public interface IContactService
    {
        List<Contact> GetAllContacts();
        Contact GetContactById(int id);
    }
}