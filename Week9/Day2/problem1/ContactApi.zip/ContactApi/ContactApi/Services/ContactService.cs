﻿using ContactApi.Models;
using ContactApi.Repositories;
using Microsoft.Extensions.Caching.Memory;

namespace ContactApi.Services
{
    public class ContactService : IContactService
    {
        private readonly IContactRepository _repo;
        private readonly IMemoryCache _cache;

        public ContactService(IContactRepository repo, IMemoryCache cache)
        {
            _repo = repo;
            _cache = cache;
        }

        public List<Contact> GetAllContacts()
        {
            string key = "contactList";

            if (!_cache.TryGetValue(key, out List<Contact> contacts))
            {
                contacts = _repo.GetAll();

                _cache.Set(key, contacts, TimeSpan.FromSeconds(60));
            }
            else
            {
                Console.WriteLine("Fetching from Cache...");
            }

            return contacts;
        }

        public Contact GetContactById(int id)
        {
            string key = $"contact_{id}";

            if (!_cache.TryGetValue(key, out Contact contact))
            {
                contact = _repo.GetById(id);

                if (contact != null)
                {
                    _cache.Set(key, contact, TimeSpan.FromSeconds(60));
                }
            }
            else
            {
                Console.WriteLine("Fetching from Cache...");
            }

            return contact;
        }
    }
}