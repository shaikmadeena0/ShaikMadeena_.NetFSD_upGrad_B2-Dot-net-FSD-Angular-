﻿using ContactManagementApp.Models;

namespace ContactManagementApp.Interfaces
{
    public interface IContactService
    {
        void AddContact(Contact contact);
        List<Contact> GetAllContacts();
        Contact? GetContactById(int id);
        void UpdateContact(Contact contact);
        void DeleteContact(int id);
    }
}