﻿using ContactManagementApp.Interfaces;
using ContactManagementApp.Models;
using ContactManagementApp.Services;

IContactService service = new ContactService();

service.AddContact(new Contact
{
    Id = 1,
    Name = "Madee",
    Email = "madee@gmail.com",
    Phone = "1234567890"
});

var contacts = service.GetAllContacts();

foreach (var contact in contacts)
{
    Console.WriteLine(contact.Name);
}