import { Student } from "./student.model";
import { getGrade, getTopper } from "./student.service";
import { formatName, calculateAverage } from "./utils";

const students: Student[] = [
  { id: 1, name: "madee", marks: 85 },
  { id: 2, name: "shine", marks: 92 },
  { id: 3, name: "john", marks: 55 },
];

console.log("Formatted Names:");
students.forEach((s) => {
  console.log(formatName(s.name));
});

console.log("\nGrades:");
students.forEach((s) => {
  console.log(`${formatName(s.name)}: ${getGrade(s.marks)}`);
});

const avg = calculateAverage(students);
console.log("\nAverage Marks:", avg);

const topper = getTopper(students);
console.log("\nTopper:", formatName(topper.name), "-", topper.marks);
