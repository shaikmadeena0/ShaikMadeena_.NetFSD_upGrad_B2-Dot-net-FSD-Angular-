import { Component } from '@angular/core';
import { NgForm } from '@angular/forms';
import { Contact } from '../../models/contact.model';

@Component({
  selector: 'app-contact-form',
  templateUrl: './contact-form.component.html',
  styleUrls: ['./contact-form.component.css'],
})
export class ContactFormComponent {
  contacts: Contact[] = [];

  contact: Contact = {
    contactId: 0,
    name: '',
    email: '',
    phone: '',
    isActive: false,
  };

  currentId: number = 1;
  addContact(contactForm: NgForm): void {
    if (contactForm.valid) {
      const newContact: Contact = {
        contactId: this.currentId++,
        name: this.contact.name,
        email: this.contact.email,
        phone: this.contact.phone,
        isActive: this.contact.isActive,
      };

      this.contacts.push(newContact);

      contactForm.resetForm();

      this.contact = {
        contactId: 0,
        name: '',
        email: '',
        phone: '',
        isActive: false,
      };
    }
  }
}
