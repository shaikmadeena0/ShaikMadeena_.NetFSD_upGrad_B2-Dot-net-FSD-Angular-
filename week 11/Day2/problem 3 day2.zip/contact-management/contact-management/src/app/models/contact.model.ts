export interface Contact {
  contactId: number;
  name: string;
  email: string;
  phone: string;
  isActive: boolean;
}
