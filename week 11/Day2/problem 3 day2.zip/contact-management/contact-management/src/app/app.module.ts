import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import { FormsModule } from '@angular/forms';

import { ContactFormComponent } from './components/contact-form/contact-form.component';

@NgModule({
  declarations: [ContactFormComponent],
  imports: [BrowserModule, FormsModule],
  providers: [],
  bootstrap: [ContactFormComponent],
})
export class AppModule {}
